//
//  MainViewController.swift
//  Project App French.me
//
//  Created by english on 2023-11-27.
//

import UIKit

class MainViewController: UIViewController {
    
    @IBOutlet weak var txtSelectVerb: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // Method to go to another page
    @IBAction func searchButton(_ sender: Any) {
        // Verifies if there is any verb on textField
        
        
    }

    // Method to do an alert msg
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Warning", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        guard let verb = txtSelectVerb.text, !verb.isEmpty else {
            // Display a msg if there is no verb
            showAlert(message: "Please, insert a verb.")
            return false
        }
        return true
    }
}

