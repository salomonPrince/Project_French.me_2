//
//  LoginViewController.swift
//  Project App French.me
//
//  Created by english on 2023-11-27.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnShowPassword: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtPassword.isSecureTextEntry = true
        
    }

    func isValidUser(email: String, password: String) -> Bool {
        // Check if the entered email and password match the hardcoded values
        return email == "tester@gmail.com" && password == "12345"
    }
    
    @IBAction func btnToggleShowHidePassword(_ sender: Any) {
        
        txtPassword.isSecureTextEntry.toggle()
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        guard let email = txtEmail.text, !email.isEmpty,
              let password = txtPassword.text, !password.isEmpty
        else {
            Toast.ok(view: self, title: "Error", message: "Fill all fields")
            return false
        }

        if isValidUser(email: email, password: password) {
            // User entered
            return true
        } else {
            // Display an error msg
            Toast.ok(view: self, title: "Error", message: "Email or Password invalid. Try again.")
            return false
        }
        
    }
    
}
