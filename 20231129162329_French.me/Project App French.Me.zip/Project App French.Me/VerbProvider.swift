//
//  VerbProvider.swift
//  Project App French.me
//
//  Created by english on 2023-11-27.
//

import Foundation


class VerbProvider {
    
    
    static var conjugation = ["Je vais", "Tu vas", "Il/elle va", "Nous allons", "Vous allez", "ils/elles vont"]
    
    
    
    
}
